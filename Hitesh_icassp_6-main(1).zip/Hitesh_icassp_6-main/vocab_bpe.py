"""
vocab_bpe.py
Subword (BPE) CTC vocabulary — a drop-in replacement for CTCVocab in vocab.py.

Why: char-level CTC means one acoustically-confused frame corrupts one
character, and long slot fillers require many independent per-frame
decisions to all be correct. A domain-trained BPE vocab shortens target
sequences substantially (fewer symbols per utterance -> fewer chances for
noise to break the sequence), which tends to help SLU-F1 specifically
under noisy conditions.

Exposes the exact same interface as vocab.CTCVocab so dataset.py / model.py
require NO changes:
    - .encode(tagged_text) -> list[int]
    - .decode(ids)         -> str  (CTC greedy collapse + detokenize)
    - .pad_id, .blank_id, len(vocab)
    - .save(path) / BPECTCVocab.load(path)

Requires: pip install tokenizers
"""
from pathlib import Path

from tokenizers import Tokenizer, models, pre_tokenizers, decoders, trainers

from vocab import END_FILL_TOKEN, UNK_TOKEN


def train_bpe_tokenizer(tagged_texts, slot_types, vocab_size=500):
    """Train a byte-level BPE tokenizer on tagged transcripts. Slot tags
    (<fill_TYPE>, <end_fill>) are registered as atomic special tokens so
    they are never split into subwords, regardless of vocab_size."""
    fill_tokens = [f"<fill_{s}>" for s in sorted(slot_types)]
    special_tokens = [UNK_TOKEN] + fill_tokens + [END_FILL_TOKEN]

    tokenizer = Tokenizer(models.BPE(unk_token=UNK_TOKEN))
    tokenizer.pre_tokenizer = pre_tokenizers.ByteLevel(add_prefix_space=True)
    tokenizer.decoder = decoders.ByteLevel()

    trainer = trainers.BpeTrainer(
        vocab_size=vocab_size,
        special_tokens=special_tokens,
        show_progress=True,
    )
    tokenizer.train_from_iterator(tagged_texts, trainer=trainer)
    # Re-assert special tokens as atomic AddedTokens so they always survive
    # pre-tokenization intact, even on unseen text at inference time.
    tokenizer.add_special_tokens(special_tokens)
    return tokenizer


class BPECTCVocab:
    def __init__(self, tokenizer: Tokenizer):
        self.tokenizer = tokenizer
        self.vocab_size = tokenizer.get_vocab_size()
        # blank lives *outside* the tokenizer's own vocab, as one extra
        # trailing id -> ctc_head output dim must be vocab_size + 1.
        self.blank_id = self.vocab_size
        self.pad_id = self.blank_id  # padding region is masked out via
                                      # target_lens in ctc_loss, so any
                                      # valid id works here.

    def __len__(self):
        return self.vocab_size + 1  # + blank

    def encode(self, tagged_text: str):
        return self.tokenizer.encode(tagged_text).ids

    def decode(self, ids):
        # Standard CTC greedy collapse: dedupe consecutive repeats, drop blank.
        collapsed, prev = [], None
        for i in ids:
            if i == prev:
                continue
            prev = i
            if i == self.blank_id:
                continue
            collapsed.append(i)
        return self.tokenizer.decode(collapsed, skip_special_tokens=False)

    def save(self, path):
        self.tokenizer.save(str(path))

    @classmethod
    def load(cls, path):
        tokenizer = Tokenizer.from_file(str(path))
        return cls(tokenizer)


def build_bpe_vocab_from_jsonl(jsonl_paths, vocab_size=500, save_path=None):
    """Convenience helper mirroring vocab.build_label_maps + CTCVocab(...)
    for the char-level path, but for BPE."""
    import json
    from vocab import SLOT_SPAN_RE, annotation_to_tagged_text

    tagged_texts, slot_types = [], set()
    for path in jsonl_paths:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                rec = json.loads(line)
                ann = rec.get("sentence_annotation") or rec.get("sentence", "")
                for m in SLOT_SPAN_RE.finditer(ann):
                    slot_types.add(m.group(1))
                tagged_texts.append(annotation_to_tagged_text(ann))

    tokenizer = train_bpe_tokenizer(tagged_texts, slot_types, vocab_size=vocab_size)
    vocab = BPECTCVocab(tokenizer)
    if save_path is not None:
        vocab.save(save_path)
    return vocab
