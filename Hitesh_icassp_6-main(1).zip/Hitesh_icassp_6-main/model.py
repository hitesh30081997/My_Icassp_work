"""
model.py
HuBERT/WavLM-based end-to-end SLU model.

Design
------
Self-supervised speech encoders (HuBERT, WavLM) carry different information
across depth: lower layers ~ acoustic/phonetic, middle layers ~ phonetic-to-
semantic transition, and layer ~8 (of 12 in the *-base models) is commonly
reported as a strong layer for semantic/word-content tasks. Rather than
committing to one fixed layer, this model supports two modes:

  - "single": read out one fixed `hidden_states[semantic_layer]` (the
    original approach).
  - "weighted_sum": a SUPERB-style *learned* weighted sum over a range of
    layers, softmax-normalized so it always sums to 1. Intent and slot
    filling get their OWN independent weighted-sum modules, since they may
    genuinely want different layers to matter most (intent needs a rough
    global gist; slots need precise, frame-local acoustic/lexical detail) --
    letting each branch learn its own mixture removes the need to guess a
    single "best" layer per task.

Both branches feed from whichever representation `layer_fusion` produces:

  1. Intent classification head
     Attention pooling over time -> linear classifier over the SLURP
     intent set (scenario_action).

  2. Slot filling head
     A light BiLSTM refines the features temporally, followed by a linear
     CTC projection over a vocabulary that includes both text characters
     (or BPE subwords) and slot-boundary tags (see vocab.py / vocab_bpe.py).
     CTC lets us train directly against speech <-> tagged-transcript pairs
     without any forced alignment.

Total loss = intent_ce_loss + ctc_loss_weight * ctc_loss
"""
import torch
import torch.nn as nn
from transformers import AutoModel


class AttentionPool(nn.Module):
    """Simple additive attention pooling over the time dimension."""

    def __init__(self, hidden_size):
        super().__init__()
        self.proj = nn.Linear(hidden_size, hidden_size)
        self.score = nn.Linear(hidden_size, 1)

    def forward(self, x, mask):
        # x: (B, T, H), mask: (B, T) with 1 for valid frames
        scores = self.score(torch.tanh(self.proj(x))).squeeze(-1)  # (B, T)
        scores = scores.masked_fill(mask == 0, float("-inf"))
        weights = torch.softmax(scores, dim=-1).unsqueeze(-1)      # (B, T, 1)
        pooled = (x * weights).sum(dim=1)                          # (B, H)
        return pooled


class LayerWeightedSum(nn.Module):
    """SUPERB-style learned weighted sum over a fixed set of encoder layers.

    Weights are free parameters passed through softmax, so they always form
    a valid convex combination (no manual normalization needed) and can be
    inspected post-training to see which layers a given task actually
    relies on.
    """

    def __init__(self, num_layers: int):
        super().__init__()
        self.raw_weights = nn.Parameter(torch.zeros(num_layers))
        self.gamma = nn.Parameter(torch.ones(1))  # optional overall scale

    def forward(self, layer_feats):
        # layer_feats: list of (B, T, H) tensors, one per selected layer
        stacked = torch.stack(layer_feats, dim=0)               # (L, B, T, H)
        weights = torch.softmax(self.raw_weights, dim=0).view(-1, 1, 1, 1)
        fused = (stacked * weights).sum(dim=0)                  # (B, T, H)
        return self.gamma * fused

    def normalized_weights(self):
        return torch.softmax(self.raw_weights, dim=0).detach().cpu()


class HubertSLUModel(nn.Module):
    def __init__(
        self,
        num_intents: int,
        ctc_vocab_size: int,
        pad_id: int,
        blank_id: int,
        hubert_name: str = "facebook/hubert-base-ls960",
        semantic_layer: int = 8,
        layer_fusion: str = "single",     # "single" | "weighted_sum"
        fusion_layers: list = None,       # hidden_states indices to fuse over; None = all
        freeze_feature_extractor: bool = True,
        freeze_encoder_layers: int = 0,
        slot_lstm_hidden: int = 256,
        slot_lstm_layers: int = 2,
        dropout: float = 0.1,
        blank_bias_init: float = -2.0,
    ):
        super().__init__()
        self.semantic_layer = semantic_layer
        self.layer_fusion = layer_fusion
        self.pad_id = pad_id
        self._ctc_blank_id = blank_id

        # AutoModel dispatches to HubertModel, WavLMModel, Wav2Vec2Model, etc.
        # based on the checkpoint's config -- same attribute names
        # (feature_extractor, encoder.layers, hidden_states output) across
        # all three, so the rest of this class is backbone-agnostic.
        self.hubert = AutoModel.from_pretrained(hubert_name)
        hidden_size = self.hubert.config.hidden_size
        num_hidden_layers = self.hubert.config.num_hidden_layers

        if freeze_feature_extractor:
            self.hubert.feature_extractor._freeze_parameters()

        if freeze_encoder_layers > 0:
            for i, layer in enumerate(self.hubert.encoder.layers):
                if i < freeze_encoder_layers:
                    for p in layer.parameters():
                        p.requires_grad = False

        # hidden_states indices to fuse over (index 0 = CNN output before any
        # Transformer block, indices 1..num_hidden_layers = block outputs).
        # Default: fuse over every Transformer block output.
        self.fusion_layers = fusion_layers or list(range(1, num_hidden_layers + 1))

        if self.layer_fusion == "weighted_sum":
            # Separate learned mixtures per task -- intent and slots are
            # free to rely on different layers.
            self.intent_layer_fusion = LayerWeightedSum(len(self.fusion_layers))
            self.slot_layer_fusion = LayerWeightedSum(len(self.fusion_layers))

        # --- Intent branch ---
        self.intent_pool = AttentionPool(hidden_size)
        self.intent_dropout = nn.Dropout(dropout)
        self.intent_head = nn.Linear(hidden_size, num_intents)

        # --- Slot filling branch (BiLSTM + CTC over tagged transcript) ---
        self.slot_lstm = nn.LSTM(
            input_size=hidden_size,
            hidden_size=slot_lstm_hidden,
            num_layers=slot_lstm_layers,
            batch_first=True,
            bidirectional=True,
            dropout=dropout if slot_lstm_layers > 1 else 0.0,
        )
        self.slot_dropout = nn.Dropout(dropout)
        self.ctc_head = nn.Linear(slot_lstm_hidden * 2, ctc_vocab_size)
        # Blank collapse (model predicting <blank> at every frame) is a
        # common CTC local minimum early in training. Bias-initialize the
        # blank logit downward so blank isn't the trivially cheapest output
        # at step 0 -- makes non-blank symbols relatively more attractive
        # while training finds real structure, without fully preventing
        # legitimate blank predictions once the model is actually trained.
        with torch.no_grad():
            self.ctc_head.bias[blank_id] = blank_bias_init

    def _feature_mask_from_attention_mask(self, attention_mask):
        """Convert raw-waveform attention mask to the (shorter) feature-frame
        mask that matches the CNN downsampling, using HF's helper."""
        feat_lens = self.hubert._get_feat_extract_output_lengths(
            attention_mask.sum(-1)
        )
        max_len = int(feat_lens.max().item())
        frame_mask = torch.arange(max_len, device=attention_mask.device)[None, :] < feat_lens[:, None]
        return frame_mask.long(), feat_lens

    def forward(self, input_values, attention_mask, ctc_target_lens=None):
        outputs = self.hubert(
            input_values=input_values,
            attention_mask=attention_mask,
            output_hidden_states=True,
        )

        if self.layer_fusion == "weighted_sum":
            selected = [outputs.hidden_states[i] for i in self.fusion_layers]
            intent_feats = self.intent_layer_fusion(selected)   # (B, T, H)
            slot_feats_in = self.slot_layer_fusion(selected)    # (B, T, H)
        else:
            # hidden_states[0] = CNN output before any Transformer block;
            # hidden_states[semantic_layer] = output after that block.
            feats = outputs.hidden_states[self.semantic_layer]
            intent_feats = feats
            slot_feats_in = feats

        frame_mask, feat_lens = self._feature_mask_from_attention_mask(attention_mask)
        # hidden_states time dim can be off by a few frames from our computed
        # lengths on some torch/audio versions; clip defensively.
        T = intent_feats.shape[1]
        frame_mask = frame_mask[:, :T]
        feat_lens = feat_lens.clamp(max=T)

        # ---- Intent classification ----
        pooled = self.intent_pool(intent_feats, frame_mask)
        intent_logits = self.intent_head(self.intent_dropout(pooled))

        # ---- Slot filling (CTC) ----
        slot_feats, _ = self.slot_lstm(slot_feats_in)
        slot_feats = self.slot_dropout(slot_feats)
        ctc_logits = self.ctc_head(slot_feats)                      # (B, T, V)
        log_probs = torch.log_softmax(ctc_logits, dim=-1).transpose(0, 1)  # (T, B, V) for CTCLoss

        return {
            "intent_logits": intent_logits,
            "ctc_log_probs": log_probs,
            "feat_lens": feat_lens,
        }

    def compute_loss(self, batch, outputs, ctc_loss_weight=1.0):
        intent_loss = nn.functional.cross_entropy(
            outputs["intent_logits"], batch["intent_ids"]
        )
        ctc_loss = nn.functional.ctc_loss(
            outputs["ctc_log_probs"],
            batch["ctc_targets"],
            outputs["feat_lens"],
            batch["ctc_target_lens"],
            blank=self._ctc_blank_id,
            zero_infinity=True,
        )
        total = intent_loss + ctc_loss_weight * ctc_loss
        return total, intent_loss.detach(), ctc_loss.detach()

    def log_layer_fusion_weights(self):
        """Returns {'intent': [...], 'slot': [...]} of normalized per-layer
        weights (aligned with self.fusion_layers), or None if not using
        weighted_sum fusion. Useful for seeing which layers each task
        actually learned to rely on."""
        if self.layer_fusion != "weighted_sum":
            return None
        return {
            "layers": self.fusion_layers,
            "intent": self.intent_layer_fusion.normalized_weights().tolist(),
            "slot": self.slot_layer_fusion.normalized_weights().tolist(),
        }
